import sqlite3
from tkinter import *
#import tkMessageBox
from tkinter import messagebox

class login:

    def __init__(self):
        self.db = sqlite3.connect(":memory:")
        self.db = sqlite3.connect("data.db")
        self.cursor = self.db.cursor()
        self.window1 = Tk()
        self.window1.title("Password saver login")
        self.window1.geometry("400x300")
        self.label_username = Label(self.window1 , text = "username : ")
        self.username = Entry(self.window1)
        self.label_password = Label(self.window1 , text = "password : ")
        self.password = Entry(self.window1 , show="*")
        self.label_status = Label(self.window1 , text = "")
        self.button_login = Button(self.window1 , text = "login" , command=self.tes)
        self.label_username.grid(column=0 , row=0)
        self.username.grid(column=1 , row=0)
        self.label_password.grid(column=0 , row=1)
        self.password.grid(column=1 , row=1)
        self.button_login.grid(column=0 , row=2)
        self.label_status.grid(column=1 , row=5)
        self.text= ''
        self.signup_button = Button(self.window1 , text = "click this button for add an user" , command=self.signup)
        self.signup_button.grid(column=1 , row=4)
        self.window1.eval('tk::PlaceWindow . center')
        self.window1.mainloop()

    def tes(self):
        username = self.username.get()
        password = self.password.get()
        sql = "select * from user_account where username = '{}' and password = '{}'".format(username , password)
        self.cursor.execute(sql)
        self.db.commit()
        total = len(self.cursor.fetchall())
        if total == 0:
            self.label_status.config(text = "Wrong password or this user is not registered")
        else:
            self.label_status.config(text = "Password correct")
            password_saver(username)

    def signup(self):
        create_account()
        self.window1.destroy()

class create_account:

    def __init__(self):
        self.db = sqlite3.connect(":memory:")
        self.db = sqlite3.connect('data.db')
        self.cursor = self.db.cursor()
        self.window = Tk()
        self.window.title("Password saver sign up")
        self.window.geometry('400x300')
        self.label_username = Label(self.window , text="username : ")
        self.username = Entry(self.window)
        self.label_password = Label(self.window , text="password : ")
        self.password = Entry(self.window , show="*")
        self.button_signup = Button(self.window , text="Create account" , command=self.create_acc)
        self.label_username.grid(column=0 , row=0)
        self.username.grid(column=1 , row=0)
        self.label_password.grid(column=0 , row=1)
        self.password.grid(column=1 , row=1)
        self.button_signup.grid(column=1 , row=2)
        self.label_status = Label(self.window , text="")
        self.label_status.grid(column=1 , row=3)
        self.window.eval('tk::PlaceWindow . center')
        #self.window.mainloop()

    def create_acc(self):
        username = self.username.get()
        password = self.password.get()
        sql = "select * from user_account where username = '{}'".format(username)
        self.cursor.execute(sql)
        total = len(self.cursor.fetchall())
        if total > 0:
            self.label_status.config(text = "Please use other username")
        else:
            sql = "insert into user_account (username , password) values ('{}' , '{}')".format(username , password)
            self.cursor.execute(sql)
            self.db.commit()
            self.window.destroy()
            login()

class password_saver:

    def __init__(self , user):
        self.user = user
        self.db = sqlite3.connect(":memory:")
        self.db = sqlite3.connect("data.db")
        self.cursor = self.db.cursor()
        self.window = Tk()
        self.label_username = Label(self.window , text="username : ")
        self.username = Entry(self.window)
        self.label_password = Label(self.window , text="password : ")
        self.password = Entry(self.window)
        self.label = Label(self.window , text="Label : ")
        self.label_entry = Entry(self.window)
        sql = "select * from data where user = '{}'".format(self.user)
        self.cursor.execute(sql)
        self.db.commit()
        data = self.cursor.fetchall()
        x = []
        for i in data:
            x.append(i[2])
        self.variable = StringVar(self.window)
        #variable.set(x[0])
        self.variable.set("Select your label")
        self.list_data = OptionMenu(self.window , self.variable , "")
        if len(x) > 0:
            self.list_data = OptionMenu(self.window , self.variable , *x)
        else:
            self.list_data = OptionMenu(self.window , self.variable , "")
        self.window.geometry('400x300')
        self.label_username.grid(column=0 , row=0)
        self.username.grid(column=1,row=0)
        self.label_password.grid(column=0 , row=1)
        self.password.grid(column=1 , row=1)
        self.label.grid(column=0 , row=2)
        self.label_entry.grid(column=1 , row=2)
        self.button_add = Button(self.window , text="add data" , command = self.add_data)
        self.button_add.grid(column=0 , row=3)
        self.list_data.grid(column=1 , row=4)
        self.username_label = Label(self.window , text = "username : ")
        self.password_label = Label(self.window , text = "password : ")
        self.button_view = Button(self.window , text = "view" , command=self.view)
        self.button_view.grid(column=0 , row=5)
        self.username_label.grid(column=0 , row=6)
        self.password_label.grid(column=0 , row=7)

    def view(self):
        label = self.variable.get()
        sql = "select * from data where account = '{}' and user = '{}'".format(label , self.user)
        self.cursor.execute(sql)
        self.db.commit()
        dat = self.cursor.fetchall()
        for i in dat:
            self.username_label.config(text = "username : " + i[0])
            self.password_label.config(text = "password : " + i[1])
    def add_data(self):
        username = self.username.get()
        password = self.password.get()
        label = self.label_entry.get()
        if username == "" and password == "" and label == "":
            messagebox.showerror(title = "error" , message="please enter your username , password , label")
        else:
            sql = "select * from data where account = '{}' and user = '{}'".format(label , username)
            self.cursor.execute(sql)
            self.db.commit()
            total = self.cursor.fetchall()
            if len(total) > 0:
                messagebox.showerror(title = "error" , message = "please choose another label")
            else:
                sql = "insert into data (username , password , account , user) values ('{}' , '{}' , '{}' , '{}')".format(username , password , label , self.user)
                self.cursor.execute(sql)
                self.db.commit()
                password_saver(self.user)
                self.window.destroy()



login()
