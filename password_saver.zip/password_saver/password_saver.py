import sqlite3
import os
import getpass

class password_saver:

    def __init__(self):
        self.os_name = os.name
        self.db = sqlite3.connect(":memory:")
        self.db = sqlite3.connect("data.db")
        self.cursor = self.db.cursor()
        self.username = ''
        self.main_menu()

    def main_menu(self):
        command = input("password saver # ")
        try:
            data = command.split(" ")
            if data[0] == "adduser":
                if len(data) < 1:
                    print("usage : adduser <username> <password>")
                username = data[1]
                password = data[2]
                sql = "insert into user_account (username , password) values ('{}' , '{}')".format(username , password)
                self.cursor.execute(sql)
                self.db.commit()
                if self.os_name == "nt":
                    os.system("cls")
                else:
                    os.system("clear")
                self.main()

            elif data[0] == "login":
                username = input("username : ")
                password = getpass.getpass("password : ")
                sql = "select * from user_account where username = '{}'".format(username)
                self.cursor.execute(sql)
                self.db.commit()
                total = self.cursor.fetchall()
                if len(total) == 0:
                    print("This user is not registered")
                else:
                    sql = "select * from user_account where username = '{}' and password = '{}'".format(username , password)
                    self.cursor.execute(sql)
                    self.db.commit()
                    total = len(self.cursor.fetchall())
                    if total == 0:
                        print("wrong password for" , username)
                    else:
                        self.username = username
                        self.main()

            elif data[0] == "exit":
                exit()

            else:
                print("adduser usage : adduser <username> <password>")
                print("login")
                print("exit : for closing this program")
                self.main_menu()
        except Exception as e:
            print("Error {}".format(e))

    def main(self):
        command = input("password saver ({})>".format(self.username))
        if command == "add":
            username = input("username : ")
            password = getpass.getpass("password : ")
            account = input("account (example : instagram , facebook etc) : ")
            sql = "insert into data (username , password , account , user) values ('{}' , '{}' , '{}' , '{}')".format(username , password , account , self.username)
            self.cursor.execute(sql)
            self.db.commit()

        elif command == "show":
            sql = "select * from data where user = '{}'".format(self.username)
            self.cursor.execute(sql)
            self.db.commit()
            data = self.cursor.fetchall()

            for i in data:
                print("username : {}".format(i[0]))
                print("password : {}".format(i[1]))
                print("account : {}".format(i[2]))
                print("")

        elif command == "delete":
            username = input("username : ")
            x = input("Do you want to delete this data? [y/n] ")
            x = x.upper()
            if x == "Y":
                sql = "delete from data where username = '{}'".format(username)
                self.cursor.execute(sql)
                self.db.commit()
                print("Deleted")
            else:
                self.main()
        elif command == "exit":
            exit()

        else:
            self.usage()

        self.main()
    def usage(self):
        print("add : for adding a data")
        print("show : for showing your data")
        print("delete : for deleting your data")
        print("exit : for closing this program")
        self.main()

password_saver()
