import os
import discord
import random
import wikipedia
import sqlite3

db = sqlite3.connect(":memory:")
db = sqlite3.connect("math_bot.db")
cursor = db.cursor()
#from dotenv import load_dotenv
quiz = False
#load_dotenv()
TOKEN = "YOUR BOT TOKEN"
client = discord.Client()
xy = 0
custom_quiz_result = 0
custom_quiz = False
@client.event 
async def on_ready():
    await client.change_presence(activity=discord.Activity(name="Discord", type=1))
    print('{} has connected'.format(client.user))
@client.event
async def on_message(message):
    global quiz
    global xy
    global custom_quiz
    global custom_quiz_result
    global db
    global cursor

    if message.content.startswith("math_bot"):
        try:
            data = message.content.split(" ")
            if data[1] == 'help':
                data = "example : math_bot 1+2\n + : for addition\n - : for subtraction\n *  is for multiplication\n / : for division\n ** : for exponent\n use math_bot quiz for give you a question\n use math_bot create_quiz <your question> for make your own question"
                await message.channel.send(data)
            elif data[1] == 'quiz':
                question = str(random.randint(0 , 20)) + "+" + str(random.randint(0 , 30)) + "*" + str(random.randint(0 , 20)) + "-" + str(random.randint(0,20))
                await message.channel.send("{} = ? use math_bot answer <your answer> for answer this question".format(question))
                data_ = eval(question)
                xy = data_
                quiz = True
            elif data[1] == 'answer':
                if quiz == True:
                    answer = data[2]
                    print(xy)
                    if int(answer) == xy:
                        await message.channel.send("Good job {} you got 5 xp".format(message.author.mention))
                        quiz = False
                        username = message.author
                        sql = "select * from scores where username = '{}'".format(username)
                        cursor.execute(sql)
                        db.commit()

                        total = cursor.fetchall()
                        if len(total) < 1:
                            sql = "insert into scores (username , score) values ('{}' , {})".format(username , 5)
                            cursor.execute(sql)
                            db.commit()
                        else:
                            xp = 0
                            for i in total:
                                xp = i[1]
                            xp += 5
                            sql = "update scores set score = {} where username = '{}'".format(xp , message.author)
                            cursor.execute(sql)
                            db.commit()


                    else:
                        await message.channel.send("Your answer is wrong {}".format(message.author.mention))

            elif data[1] == 'create_quiz':
                if custom_quiz == False:
                    question = data[2]
                    await message.channel.send("{} = ? this question is from {}. Use math_bot answer2 <your answer> for answer this question".format(question , message.author.mention))
                    custom_quiz = True
                    custom_quiz_result = eval(question)

            elif data[1] == 'answer2':
                if custom_quiz == True:
                    answer = data[2]
                    if int(answer) == custom_quiz_result:
                        await message.channel.send("Your answer is correct {}. You got 5 xp".format(message.author.mention))
                        custom_quiz = False
                        username = message.author
                        sql = "select * from scores where username = '{}'".format(username)
                        cursor.execute(sql)
                        db.commit()

                        total = cursor.fetchall()
                        if len(total) < 1:
                            sql = "insert into scores (username , score) values ('{}' , {})".format(username , 5)
                            cursor.execute(sql)
                            db.commit()
                        else:
                            xp = 0
                            for i in total:
                                xp = i[1]
                            xp += 5
                            sql = "update scores set score = {} where username = '{}'".format(xp , message.author)
                            cursor.execute(sql)
                            db.commit()


                    else:
                        await message.channel.send("Your answer is incorrect {}".format(message.author.mention))

            elif data[1] == 'my_score':
                user1 = str(message.author)
                data = user1.split("#")
                sql = "select * from scores where username = '{}'".format(user1)
                cursor.execute(sql)
                db.commit()
                x = cursor.fetchall()
                y = 0
                for i in x:
                    y = i[1]

                await message.channel.send("@{} your score is {}".format(message.author.mention , y))
            elif data[1] == 'wikipedia':
                search_contain = data[2]
                result = wikipedia.page(search_contain)
                print(result.content)
                await message.channel.send(result.content)
            elif data[1] == 'info':
                info = '- This bot was created by Rice_Cake.\n - This bot written in Python3.\n - The version of this bot is 1.4.\n - You can download the source code in http://ricecake123.github.io\n'
                await message.channel.send(info)
            else:
                x = data[1]
                result = eval(data[1])
                data = "the result is : {}".format(result)
                await message.channel.send(data)
        except Exception as e:
            data = "example : math_bot 1+2\n + : for addition\n - : for subtraction\n *  is for multiplication\n / : for division\n ** : for exponent\n use math_bot question for give you a question "
            #await message.channel.send("pls math_bot help")
            print(e)

client.run(TOKEN)
