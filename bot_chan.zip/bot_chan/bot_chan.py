import os
import discord
import random
import wikipedia
import sqlite3
import requests
from googletrans import Translator
import time
import threading
import asyncio

db = sqlite3.connect(":memory:")
db = sqlite3.connect("math_bot.db")
cursor = db.cursor()
#from dotenv import load_dotenv
quiz = False
#load_dotenv()
TOKEN = "your token"
client = discord.Client()
xy = 0
custom_quiz_result = 0
custom_quiz = False
voting = False
yes = 0
no = 0
msg1 = ""
voting_author = ''
voted = []
@client.event 
async def on_ready():
    await client.change_presence(activity=discord.Activity(name="Discord", type=1))
    print('{} has connected'.format(client.user))
@client.event
async def on_message(message):
    global voting_author
    global quiz
    global xy
    global custom_quiz
    global custom_quiz_result
    global db
    global cursor
    global voting
    global yes
    global no
    global msg1
    global voted

    if message.content.startswith("bot_chan"):
        try:
            data = message.content.split(" ")
            if data[1] == 'help':
                embed = discord.Embed(title = "help" , description = "Thanks for using my bot!!")
                data = "bot_chan do_math <your operation> + : for addition , - : for subtraction ,*  is for multiplication, / : for division, ** : for exponent\n use bot_chan quiz for give you a math question\n use bot_chan create_quiz <your math question> for make your own math question"
                embed.add_field(name = "math command" , value=data , inline = False)
                embed.add_field(name = "voting" , value = "use bot_chan voting <text> for create a voting\n use bot_chan vote <choice> for choice yes or no\n use bot_chan stopvoting for stop your voting\n" , inline = False)
                embed.add_field(name = "image" , value = "use bot_chan meme for give you a meme\n use bot_chan cat_image for give you an image of cat\n" , inline = False)
                embed.add_field(name = "anime" , value = "use bot_chan anime <the name of anime>" , inline = False)
                embed.add_field(name = "wikipedia" , value = "use bot_chan wikipedia <item> " , inline = False)
                embed.add_field(name = "translate" , value = "use bot_chan translate <language> <your text> (please use - instead of space button" , inline = False)
                await message.channel.send(embed=embed)
            elif data[1] == 'quiz':
                question = str(random.randint(0 , 20)) + "+" + str(random.randint(0 , 30)) + "*" + str(random.randint(0 , 20)) + "-" + str(random.randint(0,20))
                embed = discord.Embed(title = "Math question" , description = "{} = ? use id_bot answer <your answer> for answer this question".format(question))
                await message.channel.send(embed=embed)
                data_ = eval(question)
                xy = data_
                quiz = True
            elif data[1] == 'answer':
                if quiz == True:
                    answer = data[2]
                    print(xy)
                    if int(answer) == xy:
                        msg = "Good job {} you got 5 xp".format(message.author.mention)
                        embed = discord.Embed(title = 'Your answer is correct' , description=msg)
                        await message.channel.send(embed=embed)
                        quiz = False
                        username = message.author
                        sql = "select * from scores where username = '{}'".format(username)
                        cursor.execute(sql)
                        db.commit()

                        total = cursor.fetchall()
                        if len(total) < 1:
                            sql = "insert into scores (username , score) values ('{}' , {})".format(username , 5)
                            cursor.execute(sql)
                            db.commit()
                        else:
                            xp = 0
                            for i in total:
                                xp = i[1]
                            xp += 5
                            sql = "update scores set score = {} where username = '{}'".format(xp , message.author , color=0x00ff00)
                            cursor.execute(sql)
                            db.commit()


                    else:
                        msg = "Your answer is wrong {}".format(message.author.mention)
                        embed = discord.Embed(title="Your answer is incorrect" , description=msg , color = 0x00ff00)
                        await message.channel.send(embed=embed)

            elif data[1] == 'create_math_question':
                if custom_quiz == False:
                    question = data[2]
                    embed = discord.Embed(title = "Math question" , description = "{} = ? this question is from {}. Use bot_chan answer2 <your answer> for answer this question".format(question , message.author.mention , color = 0x00ff00))
                    await message.channel.send(embed=embed)
                    custom_quiz = True
                    custom_quiz_result = eval(question)

            elif data[1] == 'answer2':
                if custom_quiz == True:
                    answer = data[2]
                    if int(answer) == custom_quiz_result:
                        await message.channel.send("Your answer is correct {}. You got 5 xp".format(message.author.mention))
                        custom_quiz = False
                        username = message.author
                        sql = "select * from scores where username = '{}'".format(username)
                        cursor.execute(sql)
                        db.commit()

                        total = cursor.fetchall()
                        if len(total) < 1:
                            sql = "insert into scores (username , score) values ('{}' , {})".format(username , 5)
                            cursor.execute(sql)
                            db.commit()
                        else:
                            xp = 0
                            for i in total:
                                xp = i[1]
                            xp += 5
                            sql = "update scores set score = {} where username = '{}'".format(xp , message.author)
                            cursor.execute(sql)
                            db.commit()


                    else:
                        await message.channel.send("Your answer is incorrect {}".format(message.author.mention))

            elif data[1] == 'my_score':
                user1 = str(message.author)
                data = user1.split("#")
                sql = "select * from scores where username = '{}'".format(user1)
                cursor.execute(sql)
                db.commit()
                x = cursor.fetchall()
                y = 0
                for i in x:
                    y = i[1]
                embed = discord.Embed(title = 'your score' , description = "{} your score is {}".format(message.author.mention , y))
                await message.channel.send(embed=embed)
            elif data[1] == 'wikipedia':
                search_contain = data[2]
                result = wikipedia.summary(search_contain , sentences = 5)
                embed = discord.Embed(title = search_contain , description=result , color = 0x00ff00)
                print(result)
                await message.channel.send(embed=embed)
            elif data[1] == 'info': 
                info = '- This bot was created by Rice_Cake.\n - This bot written in Python3.\n - The version of this bot is 1.8.\n - You can download the source code in http://ricecake123.github.io\n'
                embed = discord.Embed(title = "bot_chan info" , description=info , color=0x00ff00)
                await message.channel.send(embed=embed)

            elif data[1] == 'meme':
                response = requests.get("https://some-random-api.ml/meme")
                x = response.json()['image']
                await message.channel.send(x)

            elif data[1] == 'cat_image':
                response = requests.get('https://some-random-api.ml/img/cat')
                x = response.json()['link']
                await message.channel.send(x)

            elif data[1] == 'translate':
                dest = data[2]
                text = data[3]
                a = True
                try:
                    x = text.split("-")
                except Exception as e:
                    x = text
                    a = False
                if a == True:
                    translator = Translator()
                    teks = ''
                    for i in x:
                        teks = teks + " " + i
                    result = translator.translate(teks , dest=dest)
                    await message.channel.send(result.text)
                else:
                    translator = Translator()
                    result = translator.translate(x , dest=dest)
                    await message.channel.send(result.text)

            elif data[1] == 'do_math':
                data_ = data[2]
                result = eval(data_)
                embed = discord.Embed(title = "This is the result of {}".format(data[2]) , description = "{} the result is {}".format(message.author.mention , result))
                await message.channel.send(embed=embed)
                #await test1(message)
                
            elif data[1] == 'voting':
                if voting == False:
                    yes = 0
                    no = 0
                    print(str(message.author))
                    judul = str(message.author) + " started voting "
                    xx = ''
                    text = data[2]
                    if "-" in text:
                        dat = text.split("-")
                        for i in dat:
                            judul = judul + " " + i
                            xx = xx + " " + i
                    else:
                        judul = judul + " " +text
                        xx = text
                    embed = discord.Embed(title = judul , description = "{} (yes/no) use bot_chan vote <your choice>".format(xx))
                    voting = True
                    voting_author = message.author
                    await message.channel.send(embed=embed)
                    #await test1(message)
                    msg1 = message
                    #thread = threading.Thread(target=asyncio.run , args=(test1(message) ,))
                    #thread.start()
                    #send_fut = asyncio.run_coroutine_threadsafe(test1(message), client_loop)
                    #send_fut.result()
                    #await test1(message)

            elif data[1] == 'vote':
                found = False
                author = message.author
                for i in voted:
                    if i == author:
                        found = True

                if found == False:
                    if data[2] == 'yes':
                        yes = yes + 1
                    elif data[2] == 'no':
                        no = no+1
                    voted.append(author)
                    embed = discord.Embed(title = "yes = {} no = {}".format(yes , no) , description=".")
                    await message.channel.send(embed=embed)

            elif data[1] == 'stopvoting':
                author = message.author
                if author == voting_author:
                    voted.clear()
                    voting = False
                    embed = discord.Embed(title = "Vote is over" , description = "yes = {} , no = {}".format(yes , no))
                    await message.channel.send(embed=embed)



            elif data[1] == 'flag':
                print("")
                country = data[2]
                r = requests.get("https://corona.lmao.ninja/v2/countries/"+country)
                img = r.json()['countryInfo']['flag']
                await message.channel.send(img)


            elif data[1] == 'anime':
                if len(data) == 2:
                    anime_name = data[2]
                    id_ = random.randint(0 , 100)
                    url = 'https://kitsu.io/api/edge/anime?filter[text]=' + str(anime_name)
                    r = requests.get(url)
                    img = r.json()['data'][1]['attributes']['posterImage']['medium']
                    rating = r.json()['data'][1]['attributes']['averageRating']
                    embed = discord.Embed(title = anime_name , description= 'rating : {}'.format(rating))
                    embed.set_image(url=img)
                    await message.channel.send(embed=embed)
                elif len(data)>2:
                    anime_name = ''
                    for i in range(2 , len(data)):
                        print(i)
                        anime_name = anime_name + " " +data[i]
                    
                    print(anime_name)
                    url = 'https://kitsu.io/api/edge/anime?filter[text]=' + str(anime_name)
                    r = requests.get(url)
                    img = r.json()['data'][1]['attributes']['posterImage']['medium']
                    rating = r.json()['data'][1]['attributes']['synopsis']
                    x = r.json()['data'][1]['attributes']['averageRating']
                    embed = discord.Embed(title = anime_name , description= 'synopsis : {}'.format(rating))
                    embed.set_image(url=img)
                    embed.add_field(name="rating : {}".format(x) , value=".")
                    await message.channel.send(embed=embed)

            elif data[1] == 'lyrics':
                music_name = ''
                if len(data) == 2:
                    music_name = data[2]
                else:
                    x = data[2].split(" ")
                    for i in x:
                        music_name = music_name + " " + i

                url = 'https://some-random-api.ml/lyrics?title=' + music_name
                r = requests.get(url)
                title_ = r.json()['title']
                author_ = r.json()['author']
                lyrics = r.json()['lyrics']
                embed = discord.Embed(title = title_ , description = lyrics)
                #embed.add_field(name = "Lyrics" , value = lyrics , inline = False)
                await message.channel.send(embed=embed)

            else:
                embed = discord.Embed(title = "Sorry i dont understand" , description = "please type id_bot help")
                await message.channel.send(embed=embed)
        except Exception as e:
            print(e)
        
    if message.content.startswith(">"):
        try:
            data1 = message.content.split(" ")
            if len(data1) == 1:
                y = data1[1]
                print(y)
                r = requests.get("https://some-random-api.ml/chatbot?message="+y)
                data_ = r.json()['response']
                embed = discord.Embed(title = 'chat response' , description=data_)
                await message.channel.send(embed=embed)
            else:
                y = ''
                for i in range(1 , len(data1)):
                    y = y + " " + data1[i]

                print(y)
                r = requests.get('https://some-random-api.ml/chatbot?message='+y)
                data_ = r.json()['response']
                embed = discord.Embed(title='chat response' , description=data_)
                await message.channel.send(embed=embed)
        except Exception as e:
                print(e)


        #except Exception as e:
            #data = "example : math_bot 1+2\n + : for addition\n - : for subtraction\n *  is for multiplication\n / : for division\n ** : for exponent\n use math_bot question for give you a question "
            #await message.channel.send("pls math_bot help")
         #   print(e)

async def test1(message):
    global voting
    if voting == True:
        for i in range(0 , 10):
            print(message.content)
            time.sleep(1)
        embed = discord.Embed(title = "Vote is over" , description = "yes = {} , no = {}".format(yes , no))
        await message.channel.send(embed=embed)
        voting = False


#client.loop.create_task(testing())
client.run(TOKEN)
